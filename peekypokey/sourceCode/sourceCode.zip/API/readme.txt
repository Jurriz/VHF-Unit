The PeekyPokey API is not yet Open Source but is likely
to become so in future releases.