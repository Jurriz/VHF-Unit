As of yet, the PeekyPokey Toolkit resides within
the core API but will be broken out in
releases to come. At that point the Toolkit
will become Open Source independantly of the
core API.